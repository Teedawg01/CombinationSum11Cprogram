#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int** result;
    int* columnSizes;
    int returnSize;
} Solution;

int comparison(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

void backtrack(int* candidates, int candidatesSize, int target, int start, 
               int* temp, int tempSize, Solution* solution) {
    if (target == 0) {
        solution->result[solution->returnSize] = (int*)malloc(tempSize * sizeof(int));
        memcpy(solution->result[solution->returnSize], temp, tempSize * sizeof(int));
        solution->columnSizes[solution->returnSize] = tempSize;
        solution->returnSize++;
        return;
    }

    for (int i = start; i < candidatesSize && candidates[i] <= target; i++) {
        if (i > start && candidates[i] == candidates[i-1]) continue;
        temp[tempSize] = candidates[i];
        backtrack(candidates, candidatesSize, target - candidates[i],
                  i + 1, temp, tempSize + 1, solution);
    }
}

Solution* combinationSum2(int* candidates, int candidatesSize, int target, 
                         int* returnSize, int** returnColumnSizes) {
    qsort(candidates, candidatesSize, sizeof(int), comparison);

    Solution* solution = (Solution*)malloc(sizeof(Solution));
    solution->result = (int**)malloc(1000 * sizeof(int*));
    solution->columnSizes = (int*)malloc(1000 * sizeof(int));
    solution->returnSize = 0;

    int* temp = (int*)malloc(candidatesSize * sizeof(int));

    backtrack(candidates, candidatesSize, target, 0, temp, 0, solution);

    *returnSize = solution->returnSize;
    *returnColumnSizes = solution->columnSizes;

    free(temp); // Free temp to avoid memory leak
    return solution;
}

void printResult(int** result, int returnSize, int* columnSizes) {
    printf("[\n");
    for (int i = 0; i < returnSize; i++) {
        printf("[");
        for (int j = 0; j < columnSizes[i]; j++) {
            printf("%d", result[i][j]);
            if (j < columnSizes[i] - 1) printf(",");
        }
        printf("]");
        if (i < returnSize - 1) printf(",");
        printf("\n");
    }
    printf("]\n");
}

int main() {
    // Example 1
    int candidates1[] = {10, 1, 2, 7, 6, 1, 5};
    int target1 = 8;
    int candidatesSize1 = sizeof(candidates1) / sizeof(candidates1[0]);
    int returnSize1;
    int* returnColumnSizes1;
    
    printf("Example 1:\n");
    Solution* solution1 = combinationSum2(candidates1, candidatesSize1, target1, 
                                        &returnSize1, &returnColumnSizes1);
    printResult(solution1->result, solution1->returnSize, solution1->columnSizes);
    
    // Free memory
    for (int i = 0; i < solution1->returnSize; i++) {
        free(solution1->result[i]);
    }
    free(solution1->result);
    free(solution1->columnSizes);
    free(solution1);
    
    // Example 2
    int candidates2[] = {2, 5, 2, 1, 2};
    int target2 = 5;
    int candidatesSize2 = sizeof(candidates2) / sizeof(candidates2[0]);
    int returnSize2;
    int* returnColumnSizes2;
    
    printf("\nExample 2:\n");
    Solution* solution2 = combinationSum2(candidates2, candidatesSize2, target2, 
                                        &returnSize2, &returnColumnSizes2);
    printResult(solution2->result, solution2->returnSize, solution2->columnSizes);
    
    // Free memory
    for (int i = 0; i < solution2->returnSize; i++) {
        free(solution2->result[i]);
    }
    free(solution2->result);
    free(solution2->columnSizes);
    free(solution2);
    
    return 0;
}